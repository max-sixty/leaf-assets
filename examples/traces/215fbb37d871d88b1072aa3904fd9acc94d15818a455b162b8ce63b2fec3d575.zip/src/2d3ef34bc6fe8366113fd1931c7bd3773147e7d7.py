"""Write a page comment, attach a screenshot, open it, and close it with Escape."""

import base64

from leaf_dev.page_fixtures import example_media
from playwright.sync_api import expect

PIXELS = (example_media() / "051bee487bfb5d13.png").read_bytes()


def run(page):
    page.keyboard.press("c")
    field = page.locator(".lf-page-comment-card leaf-text")
    expect(field).to_be_focused()
    page.keyboard.type("The runs table clips its last column")
    with page.expect_response(lambda response: response.url.endswith("/api/media")):
        field.evaluate(
            """(box, encoded) => {
              const bytes = Uint8Array.from(atob(encoded), char => char.charCodeAt(0));
              const transfer = new DataTransfer();
              transfer.items.add(new File([bytes], 'runs.png', {type: 'image/png'}));
              box.dispatchEvent(new ClipboardEvent('paste', {
                bubbles: true, cancelable: true, clipboardData: transfer,
              }));
            }""",
            base64.b64encode(PIXELS).decode(),
        )
    thumbnail = page.get_by_role("button", name="View attached image 1", exact=True)
    expect(thumbnail).to_be_visible()
    thumbnail.click()
    viewer = page.get_by_role("dialog", name="Image preview")
    expect(viewer).to_be_visible()
    page.keyboard.press("Escape")
    expect(viewer).to_be_hidden()
    return page.evaluate("""() => ({
      card_open: document.querySelector('.lf-page-comment-card').matches(':popover-open'),
      focus: document.activeElement?.outerHTML?.slice(0, 80),
    })""")
