"""Lifecycle and trusted inputs for one browser color scheme."""

import re
import time
from pathlib import Path
from urllib.parse import urljoin, urlsplit

from leaf.files import version_num
from leaf.findings import Finding
from leaf.registry.contract import element_declarations
from leaf.render_checks import (
    HANDOVER_DEADLINE_MS,
    SERVED_TIMEOUT_MS,
    PageNotReady,
    evaluate_probe,
    install_window_errors,
    pre_upgrade_findings,
    wait_for_probe,
    wait_for_theme,
    wait_until_ready,
)

from .readings import DevtoolsIssues, _scheme_findings, _SchemeContext


def served(page, url: str, path: str, timeout_ms: int | None = None):
    """A document this page's own server holds, read from out here.

    The one reader in the render gate that can be given a deadline. `page.evaluate`
    sends the driver no timeout at all — measured on playwright 1.62, an evaluate
    awaiting a fetch that never answers is still running at 200s — so a reading
    taken inside the page is a hang with nothing printed and no way to bound it
    from Python. `page.request` takes one, and shares the browser context's cookie
    jar, so it reads as the same authorized client the page is: the handover key
    rides in the URL and becomes a cookie on the first navigation."""
    timeout_ms = SERVED_TIMEOUT_MS if timeout_ms is None else timeout_ms
    return page.request.get(urljoin(url, path), timeout=timeout_ms)


def answer_reports(page, heard) -> None:
    """Answer every error the page reports to its agent here, handing `heard` each
    report's text, so a reading neither writes to the page's log nor draws the
    refusal a read-only server gives the post. Every other event goes through."""

    def report(route):
        event = route.request.post_data_json
        if event["kind"] != "error":
            route.continue_()
            return
        heard(event["text"])
        route.fulfill(status=204)

    page.route("**/api/event", report)


def rendered_revision(url: str, state: dict) -> int:
    """Resolve the immutable revision shown at ``url`` from the public state."""
    name = Path(urlsplit(url).path).name
    if not name:
        return state["active"]["revision"]
    version = version_num(name)
    return next(
        stamped["revision"]
        for stamped in state["versions"]
        if stamped["version"] == version
    )


def _projection_was_applied(failed_stage: str | None) -> bool:
    """Whether the readiness failure happened after authoritative presentation."""
    return failed_stage in (None, "arrived", "rendering", "pageSettled")


# The browser's own console entry for a response with an error status, in Chromium and
# WebKit alike: it names the status but not the resource, which the entry's location
# carries instead.
_FAILED_LOAD = re.compile(
    r"Failed to load resource: the server responded with a status of (\d{3})\b.*"
)


def console_finding(message, *, warnings: bool = True) -> Finding | None:
    """A console entry that says the page did not load cleanly, as a finding: an
    error, or with `warnings` a warning too.

    A response with an error status is reported as its status and URL. The console
    entry is the browser's one report of it, from the page and every frame in it, so
    nothing listens to responses for it: a response listener has every request of a
    load — a few hundred modules — sent to and built in this process. The browser
    words that entry and nothing else carries the status, so its words are read here,
    once, into the finding's fields. Any other entry keeps its words and the script
    that wrote it (`url`, empty where the browser names none)."""
    said = {"text": message.text, "url": message.location["url"]}
    if message.type == "warning" and warnings:
        return Finding("console-warning", values=said)
    if message.type != "error":
        return None
    if failed := _FAILED_LOAD.fullmatch(message.text):
        return Finding(
            "failed-load",
            values={"status": int(failed[1]), "url": message.location["url"]},
        )
    return Finding("console-error", values=said)


def window_finding(error: dict) -> Finding:
    """An error a window raised with no exception behind it (`install_window_errors`)."""
    code = "resize-loop" if error["resizeLoop"] else "window-error"
    return Finding(code, values={"text": error["text"]})


def exception_finding(error) -> Finding:
    """A native page exception, retaining the browser's throw site as well as the
    exception's message.

    Native page errors cover every document in a tab. Their stacks identify the
    failing call even when separate frames throw the same message; engines that
    supply frames alone still need the message beside them.
    """
    message, stack = str(error), error.stack
    if stack:
        message = stack if message in stack else f"{message}\n{stack}"
    return Finding("page-exception", values={"text": message})


def collect_page_exceptions(page, errors: list[Finding]) -> None:
    """Collect native exceptions from every document, as findings."""
    page.on("pageerror", lambda error: errors.append(exception_finding(error)))


def collect_page_errors(page, errors: list[Finding]) -> None:
    """Collect the page's console errors and native exceptions, from every document,
    as findings."""

    def heard(message):
        if (error := console_finding(message, warnings=False)) is not None:
            errors.append(error)

    page.on("console", heard)
    collect_page_exceptions(page, errors)


class PreUpgradeFailed(RuntimeError):
    """The authored document never reached what the pre-upgrade proof waits for.
    `finding` says what, with an empty `console` its reader fills in."""

    def __init__(self, code: str, **values):
        self.finding = Finding(code, values={**values, "console": []})
        super().__init__(str(self.finding))


INTERCEPTION_ARM = "**/__leaf_arms_interception__"


def arm_interception(page):
    """Keep this page's request interception on for the whole of its life.

    Playwright turns interception off the moment a page's route list empties, and
    requests crossing that transition are lost with nothing said about it: the
    document stops at `interactive` with no load event, or a read the runtime is
    waiting on never lands, and neither ending writes a console entry. The gate
    holds the Leaf entry through a route and takes that route away again, so a page
    it opens would otherwise see the list empty at the `unroute` — measured on the
    corpus page, with `/api/state`, `/registry.json` and `/icon.svg` still in
    flight. A route on a pattern nothing ever asks for keeps the list non-empty, so
    no such transition is ever sent. `arm_interception` in the suite's own harness
    arms the pages a test opens for the same reason.
    """
    page.route(INTERCEPTION_ARM, lambda route: route.abort())


def start_with_pre_upgrade_proof(page, url: str) -> list[Finding]:
    """Inspect the authored document while its first Leaf entry request is held, and
    return what it found there, or raise `PreUpgradeFailed`.

    The hold outlives the entry it holds. Playwright turns a page's request
    interception off as soon as its last route handler is spent, and a `times=1`
    handler is spent at the moment the entry is released — which is the moment the
    module layer starts asking for a hundred-odd files. Turning interception off
    under that burst loses requests: the document stops at `interactive` with a
    module still in flight, or with nothing in flight and no load event, and neither
    ending writes a console entry. So this handler stays registered until after the
    load event and lets a later entry request through. The `unroute` in the `finally`
    below is not the safe point either — a loaded document is not an idle one, and the
    runtime's own `/api/state` read is still open there — so the page carries
    `arm_interception` and its route list never empties at all.

    Each wait here says which arrival it gave up on, and what the page was still
    asking for. The caller reads a timeout raised out of this function as one it
    cannot attribute, and the reading it would otherwise fall back on — that the
    runtime never injected its banner — is wrong for the case that actually
    happens: a subresource the page never receives leaves the document at
    `interactive` with the runtime already running, no console entry, and no
    error. The request still open is the only thing that names the file.
    """
    from playwright.sync_api import TimeoutError as PlaywrightTimeout

    held = []
    released = False
    open_requests = set()

    def hold_entry(route):
        # Only the first is held. A later one is passed through rather than left
        # held, because this handler has to outlive the entry it holds and a
        # second hold nothing releases would be a wait with no end.
        if held:
            route.continue_()
            return
        held.append(route)

    def opened(request):
        open_requests.add(request)

    def settled(request):
        open_requests.discard(request)

    def reaching(arrival, wait):
        try:
            return wait()
        except PlaywrightTimeout:
            # Minus the entry this function is holding itself, while it is still
            # holding it: it is open because the gate chose to hold it, and naming it
            # as something the page is still asking for points a reader at the hold
            # rather than at the page. Past the release it is the page's own request
            # like any other, and the load wait below is where it would stall.
            mine = set() if released else {route.request for route in held}
            waiting = open_requests - mine
            asking = sorted({urlsplit(request.url).path for request in waiting})
            raise PreUpgradeFailed(
                "never-reached", arrival=arrival, requesting=asking
            ) from None

    page.on("request", opened)
    page.on("requestfinished", settled)
    page.on("requestfailed", settled)
    page.route("**/leaf.js", hold_entry)
    try:
        reaching("its first byte", lambda: page.goto(url, wait_until="commit"))
        reaching(
            "an authored main",
            lambda: page.wait_for_selector("body > main", state="attached"),
        )
        if page.locator('script[src$="/leaf.js"]').count() != 1:
            raise PreUpgradeFailed("entry-not-single")
        reaching("its theme stylesheet", lambda: wait_for_theme(page))
        # The held entry is a module script, which runs only once the parser is done,
        # so the whole authored document is parsed here and not yet upgraded.
        reaching(
            "the end of its markup",
            lambda: page.wait_for_function("document.readyState !== 'loading'"),
        )
        findings = [Finding.read(record) for record in pre_upgrade_findings(page)]
        if len(held) != 1:
            raise PreUpgradeFailed("entry-not-requested")
        held[0].continue_()
        released = True
        reaching("load", lambda: page.wait_for_load_state("load"))
        return findings
    finally:
        if held and not released:
            held[0].continue_()
        page.unroute("**/leaf.js", hold_entry)
        page.remove_listener("request", opened)
        page.remove_listener("requestfinished", settled)
        page.remove_listener("requestfailed", settled)


def _render_scheme(
    browser, url, scheme, viewport, served_timeout_ms, opened_pages, then=None
):
    """Read and report the browser gate for one color scheme and viewport: the
    findings that refuse the version, the ResizeObserver loop notices its retry
    policy judges (`version.render_version`), and whether every reading completed.

    `then`, when given, is handed the settled page and its registry after every reading
    here, for additional version-level readings before the page closes."""
    from playwright.sync_api import Error as PlaywrightError
    from playwright.sync_api import TimeoutError as PlaywrightTimeout

    page = browser.new_page(viewport=viewport, color_scheme=scheme)
    opened_pages.append(page)
    arm_interception(page)
    page._leaf_probe_timeout_ms = served_timeout_ms
    errors = []
    resize_notices = []

    def served_here(path):
        return served(page, url, path, timeout_ms=served_timeout_ms)

    def console_message(message):
        if (problem := console_finding(message)) is not None:
            errors.append(problem)

    def window_error(error):
        problem = window_finding(error)
        (resize_notices if problem.code == "resize-loop" else errors).append(problem)

    def ended(found, notices=(), complete=False):
        page.close()
        return (
            [finding.but(scheme=scheme) for finding in found],
            [notice.but(scheme=scheme) for notice in notices],
            complete,
        )

    def explained(code, **values):
        # The named wait says what never arrived; the console and the response
        # statuses collected above are what says why, and a refused document has
        # nothing else to offer a reader.
        console = [problem.json(text=False) for problem in [*errors, *resize_notices]]
        return ended([Finding(code, values={**values, "console": console})])

    def probe_failure(error):
        return ended([Finding("probe-failed", values={"error": str(error).strip()})])

    page.on("console", console_message)
    collect_page_exceptions(page, errors)
    # The runtime writes each report to the console too, which is where this reading
    # takes it.
    answer_reports(page, lambda text: None)
    devtools = DevtoolsIssues(page)
    install_window_errors(page, window_error)
    try:
        # Hold the entry in this navigation: this is the only point at which
        # pre-upgrade authored structure exists without racing module execution.
        pre_upgrade = start_with_pre_upgrade_proof(page, url)
        wait_for_probe(page, "runtimeStarted")
    except PlaywrightTimeout:
        return explained("no-banner")
    except PlaywrightError as error:
        return probe_failure(error)
    except PreUpgradeFailed as error:
        values = {k: v for k, v in error.finding.values.items() if k != "console"}
        return explained(error.finding.code, **values)
    # Every reading below is of a settled page. The widget layer writes half the
    # document, so a box measured while it is still drawing belongs to no version of
    # the page — which is the stamp `page export` waits on for the same reason.
    # Upgrade and readiness below are one handover, so they share its deadline: the
    # upgrade is most of a heavy page's handover, and a probe's patience is not.
    handover_ends = time.monotonic() + HANDOVER_DEADLINE_MS / 1000

    def handover_left() -> int:
        # At least 1ms: Playwright reads a zero timeout as none.
        return max(1, round((handover_ends - time.monotonic()) * 1000))

    try:
        wait_for_probe(page, "upgraded", timeout_ms=handover_left())
    except PlaywrightTimeout:
        return explained("never-upgraded")
    except PlaywrightError as error:
        return probe_failure(error)
    # The served documents every reading below is asked against, read once each
    # (`served` says why they are read from out here rather than fetched inside
    # the page). The readings get data rather than fetching it, so most of them
    # are plain synchronous DOM walks with nothing in them to await or hang in.
    try:
        registry = served_here("/registry.json").json()
        # The readings in the page consume element declarations, so they are handed
        # only those:
        # $keys spells its members in the x- keys' own names, and a sweep over
        # every declaration took it for a widget called $keys.
        declarations = element_declarations(registry)
        visual_provider_problems = evaluate_probe(
            page, "invalidVisualProviders", declarations
        )
        if visual_provider_problems:
            # The inventory is the boundary every runtime visual reading trusts. Once
            # it is invalid, the settled-page probes have no valid page to inspect.
            # What the console already said stays: another widget's failure is a
            # fault of its own, and a presentation the inventory broke is one the
            # user would see.
            return ended(
                [*errors, *pre_upgrade, *map(Finding.read, visual_provider_problems)],
                resize_notices,
                complete=True,
            )
        state = served_here("/api/state").json()
        markup = served_here(urlsplit(url).path).text()
        # Every replay check is bounded by immutable revision.
        # A stamped URL resolves through the stamp map; an exact source preview
        # uses the synthetic active revision exposed only by its preview server.
        here = rendered_revision(url, state)
    except PlaywrightTimeout as e:
        # The first line only: the rest is playwright's call log, which says
        # nothing about the page that a reader of this failure needs.
        stopped = Finding("server-stopped", values={"error": str(e).splitlines()[0]})
        return ended([*errors, *resize_notices, stopped])
    # Every reading below is of a page at rest, and the upgrade stamp above is
    # one part of that. The first read runs beside upgrade, but its answer may still
    # be pending when the stamp lands; a gate reading there sees the authored board,
    # the unanswered question and the body the user has since rewritten — a page
    # nobody is shown. The page's readiness against the reading taken above is the
    # answer to that, and the frame the log lands in is the first frame of whatever
    # the replay set moving, a replay past the presentation boundary moving rather than
    # teleporting, which `pageSettled` then waits out. Both waits are taken in both
    # schemes, because every reading below has boxes or words in it. The windows open
    # under load alone, which is how one page passed at a desk and reported words
    # drawn over words under a full suite.
    try:
        wait_until_ready(page, state, timeout_ms=handover_left())
    except PageNotReady as error:
        failed_stage = error.stage
        unsettled = [
            Finding("not-ready", values={"stage": error.stage, "error": str(error)})
        ]
    else:
        try:
            wait_for_probe(page, "pageSettled")
            failed_stage, unsettled = None, []
        except PlaywrightTimeout:
            failed_stage = "pageSettled"
            moving = evaluate_probe(page, "moving")
            unsettled = [Finding("never-settled", values={"moving": moving})]
    replayed = _projection_was_applied(failed_stage)
    context = _SchemeContext(
        page=page,
        light=scheme == "light",
        errors=[*errors, *pre_upgrade],
        registry=registry,
        declarations=declarations,
        state=state,
        markup=markup,
        here=here,
        replayed=replayed,
        unsettled=unsettled,
        devtools=devtools,
    )
    found = _scheme_findings(context)
    if then is not None:
        then(page, registry)
    return ended(found, resize_notices, complete=True)
